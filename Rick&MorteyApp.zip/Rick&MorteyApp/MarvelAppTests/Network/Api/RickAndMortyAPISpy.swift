//
//  RickAndMortyAPISpy.swift
//  MarvelAppTests
//
//  Created by mehdi.jahanmard on 12/12/22.
//

import Foundation

@testable import MarvelApp

class RickAndMortyAPISpy: RickAndMortyApi {

  // MARK: - Properties

  var getCharacterResult: Result<[CharacterEntity], GetCharactersError> = .failure(.responeProblems)

  // MARK: - Spy properties

  var getCharacterCalled = false

  // MARK: - Public

  func getCharacters(completion: @escaping (Result<[CharacterEntity], GetCharactersError>) -> Void) {
    getCharacterCalled = true
    completion(getCharacterResult)
  }
}
