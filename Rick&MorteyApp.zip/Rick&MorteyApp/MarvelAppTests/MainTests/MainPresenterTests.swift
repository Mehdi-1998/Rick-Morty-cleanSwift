//
//  MainPresenterTests.swift
//  MarvelApp
//
//  Copyright © 2022 ___ORGANIZATIONNAME___. All rights reserved.
//

import XCTest

@testable import MarvelApp

class MainPresenterTests: XCTestCase {

  // MARK: - Subject under test
  var presenter: MainPresenter?
  var viewControllerSpy: MainDisplayLogicSpy?

  // MARK: - Test lifecycle

  override func setUp() {
    super.setUp()
    setupMainPresenter()
  }

  override func tearDown() {
    super.tearDown()
  }

  // MARK: - Test setup

  func setupMainPresenter() {
    presenter = MainPresenter()
    viewControllerSpy = MainDisplayLogicSpy()
    presenter?.viewController = viewControllerSpy
  }

  // MARK: - Test doubles

  class MainDisplayLogicSpy: MainDisplayLogic {

    var displayStaticDataCalled = false
    var displaySearchCharacterCalled = false
    var displayCharacterCalled = false

    var displayStaticDataViewModel: Main.Data.ViewModel?
    var displayCharacterViewModel: Main.SelectedCharacter.ViewModel?

    func displayStaticData(viewModel: Main.Data.ViewModel) {
      displayStaticDataCalled = true
      displayStaticDataViewModel = viewModel
    }

    func displayCharacter(viewModel: MarvelApp.Main.SelectedCharacter.ViewModel) {
      displayCharacterCalled = true
      displayCharacterViewModel = viewModel
    }
  }

  // MARK: - Tests

  func testPresentStaticDataSuccess() {
    // Given
    let result: Result<[CharacterEntity], GetCharactersError> = .success(getCharacterEntity())
    let response = Main.Data.Response(result: result)

    // When
    presenter?.presentStaticData(response: response)

    // Then
    XCTAssertEqual(viewControllerSpy?.displayStaticDataCalled, true,
                   "presentStaticData() should ask the view controller to displayStaticData()")
     XCTAssertEqual(viewControllerSpy?.displayStaticDataViewModel?.action, .showData(data: getCharacterViewData()),
                   "presentStaticData() should send the correct viewModel")
  }

  func testPresentStaticDataFailure() {
    // Given
    let result: Result<[CharacterEntity], GetCharactersError> = .failure(.responeProblems)
    let response = Main.Data.Response(result: result)

    // When
    presenter?.presentStaticData(response: response)

    // Then
    XCTAssertEqual(viewControllerSpy?.displayStaticDataCalled, true,
                   "presentStaticData() should ask the view controller to displayStaticData()")
    XCTAssertEqual(viewControllerSpy?.displayStaticDataViewModel?.action,
                   .showError(error: "Impossible to show character."),
                   "presentStaticData() should send the correct viewModel")
  }

  func testCharacter() {
    // Given
    let response = Main.SelectedCharacter.Response()

    // When
    presenter?.presentCharacter(response: response)

    // Then
    XCTAssertEqual(viewControllerSpy?.displayCharacterCalled, true,
                   "presentCharacter() should ask the view controller to displayCharacter()")
  }

  // MARK: - Private

  private func getCharacterEntity() -> [CharacterEntity] {
    [
      CharacterEntity(id: 1,
                      name: "Rick Sanchez",
                      status: "Alive",
                      species: "Human",
                      type: "",
                      gender: "Male",
                      origin: OriginEntity.init(name: "Earth (C-137)",
                                                url: "https://rickandmortyapi.com/api/location/1"),
                      location: LocationEntity.init(name: "Citadel of Ricks",
                                                    url: "https://rickandmortyapi.com/api/location/3"),
                      image: "https://rickandmortyapi.com/api/character/avatar/1.jpeg",
                      url: "https://rickandmortyapi.com/api/character/2",
                      created: "2017-11-04T18:48:46.250Z",
                      episode: [""])
      ]
  }

  private func getCharacterViewData() -> MainViewData {
    let image = URL(string: "https://rickandmortyapi.com/api/character/avatar/1.jpeg")
    let characterCellData = CharacterCellData(image: image, title: "Rick Sanchez")
    return MainViewData(characters: [characterCellData])
  }
}
