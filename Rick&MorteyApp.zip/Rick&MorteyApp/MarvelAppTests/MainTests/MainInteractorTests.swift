//
//  MainInteractorTests.swift
//  MarvelApp
//
//  Copyright © 2022 ___ORGANIZATIONNAME___. All rights reserved.
//

import XCTest

@testable import MarvelApp

class MainInteractorTests: XCTestCase {

  // MARK: - Subject under test

  var interactor: MainInteractor?
  var presenterSpy: MainPresentationLogicSpy?
  var rickAndMortyApiSpy: RickAndMortyAPISpy?

  // MARK: - Test lifecycle

  override func setUp() {
    super.setUp()
    setupMainInteractor()
  }

  override func tearDown() {
    super.tearDown()
  }

  // MARK: - Test setup

  func setupMainInteractor() {
    interactor = MainInteractor()
    presenterSpy = MainPresentationLogicSpy()
    interactor?.presenter = presenterSpy
    rickAndMortyApiSpy = RickAndMortyAPISpy()
    interactor?.rickAndMortyApi = rickAndMortyApiSpy
  }

  // MARK: - Test doubles

  class MainPresentationLogicSpy: MainPresentationLogic {

    var presentStaticDataCalled = false
    var presentCharacterCalled = false

    var presentStaticDataResponse: Main.Data.Response?
    var presentCharacterResponse: Main.SelectedCharacter.Response?

    func presentStaticData(response: Main.Data.Response) {
      presentStaticDataCalled = true
      presentStaticDataResponse = response
    }

    func presentCharacter(response: Main.SelectedCharacter.Response) {
      presentCharacterCalled = true
      presentCharacterResponse = response
    }
  }

  // MARK: - Tests

  func testDoLoadStaticDataSuccess() {
    // Given
    let request = Main.Data.Request()

    // When
    rickAndMortyApiSpy?.getCharacterResult = .success(getCharacterEntity())
    interactor?.doLoadStaticData(request: request)

    // Then
    XCTAssertEqual(rickAndMortyApiSpy?.getCharacterCalled, true,
                   "doLoadStaticData() should ask the rickAndMortyApi to getCharacter()")
    XCTAssertEqual(presenterSpy?.presentStaticDataCalled, true,
                   "doLoadStaticData() should ask the presenter to presentStaticData()")
    XCTAssertEqual(presenterSpy?.presentStaticDataResponse?.result, .success(getCharacterEntity()),
                   "doLoadStaticData() should send the correct response")
  }

  func testDoLoadStaticDataFailure() {
    // Given
    let request = Main.Data.Request()

    // When
    rickAndMortyApiSpy?.getCharacterResult = .failure(.responeProblems)
    interactor?.doLoadStaticData(request: request)

    // Then
    XCTAssertEqual(rickAndMortyApiSpy?.getCharacterCalled, true,
                   "doLoadStaticData() should ask the rickAndMortyApi to getCharacter()")
    XCTAssertEqual(presenterSpy?.presentStaticDataCalled, true,
                   "doLoadStaticData() should ask the presenter to presentStaticData()")
    XCTAssertEqual(presenterSpy?.presentStaticDataResponse?.result, .failure(.responeProblems),
                   "doLoadStaticData() should send the correct response")
  }

  func testdoCharacter() {
    // Given
    let request = Main.SelectedCharacter.Request(index: 1)
    
    // When
    interactor?.characters = getCharacterEntity()
    interactor?.doSelectedCharacter(request: request)

    // Then
    XCTAssertEqual(presenterSpy?.presentCharacterCalled, true,
                   "doSelectedCharacter() should ask the presenter to presentCharacter()")
  }

  // MARK: - Private

  private func getCharacterEntity() -> [CharacterEntity] {

    [
      CharacterEntity(id: 1,
                      name: "Rick Sanchez",
                      status: "Alive",
                      species: "Human",
                      type: "",
                      gender: "Male",
                      origin: OriginEntity.init(name: "Earth (C-137)",
                                                url: "https://rickandmortyapi.com/api/location/1"),
                      location: LocationEntity.init(name: "Citadel of Ricks",
                                                    url: "https://rickandmortyapi.com/api/location/3"),
                      image: "https://rickandmortyapi.com/api/character/avatar/1.jpeg",
                      url: "https://rickandmortyapi.com/api/character/2",
                      created: "2017-11-04T18:48:46.250Z",
                      episode: [""]),

      CharacterEntity(id: 2,
                      name: "Morty Smith",
                      status: "Alive",
                      species: "Human",
                      type: "",
                      gender: "Male",
                      origin: OriginEntity.init(name: "unknown", url: ""),
                      location: LocationEntity.init(name: "Citadel of Ricks",
                                                    url: "https://rickandmortyapi.com/api/location/3"),
                      image: "https://rickandmortyapi.com/api/character/avatar/2.jpeg",
                      url: "https://rickandmortyapi.com/api/character/2",
                      created: "2017-11-04T18:50:21.651Z",
                      episode: [""])
    ]
  }
}
