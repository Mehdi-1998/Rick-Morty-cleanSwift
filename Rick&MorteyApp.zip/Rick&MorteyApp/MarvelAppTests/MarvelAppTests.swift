//
//  MarvelAppTests.swift
//  MarvelAppTests
//
//  Created by Vicente Linares, Miguel on 10/10/22.
//

import XCTest
@testable import MarvelApp

final class MarvelAppTests: XCTestCase {

    override func setUpWithError() throws {
    }

    override func tearDownWithError() throws {
    }

    func testExample() throws {
    }

    func testPerformanceExample() throws {
        self.measure {
        }
    }

}
