//
//  CharacterCell.swift
//  MarvelApp
//
//  Created by mehdi.jahanmard on 14/11/22.
//

import Kingfisher
import UIKit

struct CharacterCellData: Equatable {
  let image: URL?
  let title: String
}

class CharacterCell: UITableViewCell {

  // MARK: - Constants

  private struct ViewTraits {
    // Margins
    static let contentMarginside: CGFloat = 20
    static let contentMargin: CGFloat = 20

    // Sizes
    static let rightIconSize: CGFloat = 64

    // Fonts
    static let titleFontSize: CGFloat = 14
  }

  // MARK: - Properties

  private let titleLabel = UILabel()
  private let rightImageView = UIImageView()

  // MARK: - Lifecycle

  override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
    super.init(style: style, reuseIdentifier: reuseIdentifier)
    setupComponents()
    setupConstraints()
  }

  required init?(coder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }

  // MARK: - Public

  func setupUI(data: CharacterCellData) {
    titleLabel.text = data.title
    rightImageView.kf.setImage(with: data.image)
  }

  // MARK: - Private

  private func setupComponents() {
    titleLabel.font = .systemFont(ofSize: ViewTraits.titleFontSize)
    titleLabel.textColor = .black
    titleLabel.lineBreakMode = .byWordWrapping
    titleLabel.numberOfLines = 0

    rightImageView.contentMode = .scaleAspectFit

    contentView.addSubviewForAutolayout(titleLabel)
    contentView.addSubviewForAutolayout(rightImageView)
  }

  private func setupConstraints() {
    NSLayoutConstraint.activate([

      titleLabel.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
      titleLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: ViewTraits.contentMarginside),
      titleLabel.topAnchor.constraint(equalTo: contentView.topAnchor,
                                      constant: ViewTraits.contentMargin,
                                      priority: .defaultLow),
      titleLabel.topAnchor.constraint(greaterThanOrEqualTo: contentView.topAnchor, constant: ViewTraits.contentMargin),


      rightImageView.widthAnchor.constraint(equalToConstant: ViewTraits.rightIconSize),
      rightImageView.heightAnchor.constraint(equalToConstant: ViewTraits.rightIconSize),
      rightImageView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
      rightImageView.leadingAnchor.constraint(greaterThanOrEqualTo: titleLabel.trailingAnchor,
                                              constant: ViewTraits.contentMarginside),
      rightImageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor,
                                               constant: -ViewTraits.contentMarginside),
      rightImageView.topAnchor.constraint(equalTo: contentView.topAnchor,
                                          constant: ViewTraits.contentMargin,
                                          priority: .defaultLow),
      rightImageView.topAnchor.constraint(greaterThanOrEqualTo: contentView.topAnchor,
                                          constant: ViewTraits.contentMargin)
    ])
  }
}
