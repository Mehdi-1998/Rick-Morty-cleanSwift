//
//  EpisodeCell.swift
//  MarvelApp
//
//  Created by mehdi.jahanmard on 16/12/22.
//

import UIKit

struct EpisodeCellData: Equatable {
  let title: String
  let url: String
}

class EpisodeCell: UITableViewCell {

  // MARK: - Constants

  private struct ViewTraits {
    // Margins
    static let contentMarginside: CGFloat = 20
    static let contentMargin: CGFloat = 20

    // Sizes
    static let rightIconSize: CGFloat = 64

    // Fonts
    static let titleFontSize: CGFloat = 14
  }

  // MARK: - Properties

  private let titleLabel = UILabel()
  private let urlEpisode = UILabel()

  // MARK: - Lifecycle

  override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
    super.init(style: style, reuseIdentifier: reuseIdentifier)
    setupComponents()
    setupConstraints()
  }

  required init?(coder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }

  // MARK: - Public

  func setupUI(data: EpisodeCellData) {
    titleLabel.text = data.title
    urlEpisode.text = data.url
  }

  // MARK: - Private

  private func setupComponents() {
    titleLabel.font = .systemFont(ofSize: ViewTraits.titleFontSize)
    titleLabel.textColor = .black
    titleLabel.lineBreakMode = .byWordWrapping
    titleLabel.numberOfLines = 0

    urlEpisode.textColor = .blue

    contentView.addSubviewForAutolayout(titleLabel)
    contentView.addSubviewForAutolayout(urlEpisode)
  }

  private func setupConstraints() {
    NSLayoutConstraint.activate([

      titleLabel.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
      titleLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: ViewTraits.contentMarginside),
      titleLabel.topAnchor.constraint(equalTo: contentView.topAnchor,
                                      constant: ViewTraits.contentMargin,
                                      priority: .defaultLow),
      titleLabel.topAnchor.constraint(greaterThanOrEqualTo: contentView.topAnchor, constant: ViewTraits.contentMargin),


      urlEpisode.widthAnchor.constraint(equalToConstant: ViewTraits.rightIconSize),
      urlEpisode.heightAnchor.constraint(equalToConstant: ViewTraits.rightIconSize),
      urlEpisode.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
      urlEpisode.leadingAnchor.constraint(greaterThanOrEqualTo: titleLabel.trailingAnchor,
                                              constant: ViewTraits.contentMarginside),
      urlEpisode.trailingAnchor.constraint(equalTo: contentView.trailingAnchor,
                                               constant: -ViewTraits.contentMarginside),
      urlEpisode.topAnchor.constraint(equalTo: contentView.topAnchor,
                                          constant: ViewTraits.contentMargin,
                                          priority: .defaultLow),
      urlEpisode.topAnchor.constraint(greaterThanOrEqualTo: contentView.topAnchor,
                                          constant: ViewTraits.contentMargin)
    ])
  }
}
