//
//  EpisodeRouter.swift
//  MarvelApp
//
//  Copyright © 2022 ___ORGANIZATIONNAME___. All rights reserved.
//

import UIKit

protocol EpisodeRoutingLogic {
  func routeBack()
  func routeToCartList()
  func routeToLogin()
  func routeToMyAccount()
}

protocol EpisodeDataPassing {
  var dataStore: EpisodeDataStore? { get }
}

class EpisodeRouter: EpisodeRoutingLogic, EpisodeDataPassing {

  // MARK: - Properties

  weak var viewController: EpisodeViewController?
  var dataStore: EpisodeDataStore?

  // MARK: - Routing

  func routeBack() {
    viewController?.navigationController?.popViewController(animated: true)
  }

  func routeToCartList() {
    let destinationVC = CartsListViewController()
    let navigationController = ECINavigationController(rootViewController: destinationVC)
    navigationController.interactivePopGestureRecognizer?.delegate = destinationVC
    viewController?.present(navigationController, animated: true)
  }

  func routeToLogin() {
    let destinationVC = LoginViewController()
    if let sourceDS = dataStore, var destinationDS = destinationVC.router?.dataStore {
      destinationDS.loginReason = sourceDS.loginReason
    }
    let navigationController = ECINavigationController(rootViewController: destinationVC)
    navigationController.interactivePopGestureRecognizer?.delegate = destinationVC
    viewController?.present(navigationController, animated: true)
  }

  func routeToMyAccount() {
    let destinationVC = MyAccountViewController()
    let navigationController = ECINavigationController(rootViewController: destinationVC)
    navigationController.interactivePopGestureRecognizer?.delegate = destinationVC
    viewController?.present(navigationController, animated: true)
  }
}
