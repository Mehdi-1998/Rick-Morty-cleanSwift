//
//  EpisodeViewController.swift
//  MarvelApp
//
//  Copyright © 2022 ___ORGANIZATIONNAME___. All rights reserved.
//

import UIKit

protocol EpisodeDisplayLogic: AnyObject {
  func displayStaticData(viewModel: Episode.StaticData.ViewModel)
  func displayOpenCart(viewModel: Episode.OpenCart.ViewModel)
  func displayUpdateCart(viewModel: Episode.UpdateCart.ViewModel)
  func displayUpdateMyAccount(viewModel: Episode.UpdateMyAccount.ViewModel)
}

class EpisodeViewController: UIViewController {

  // MARK: - Properties

  var interactor: EpisodeBusinessLogic?
  var router: (EpisodeRoutingLogic & EpisodeDataPassing)?

  private let sceneView = EpisodeView()
  private let cartButton = CartBarButtonItem()
  private let myAccountButton = MyAccountBarButtonItem()

  // MARK: - Object's lifecycle

  override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
    super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    setup()
  }

  required init?(coder aDecoder: NSCoder) {
    super.init(coder: aDecoder)
    setup()
  }

  // MARK: - Setup

  private func setup() {
    let viewController = self
    let interactor = EpisodeInteractor()
    let presenter = EpisodePresenter()
    let router = EpisodeRouter()
    viewController.interactor = interactor
    viewController.router = router
    interactor.presenter = presenter
    interactor.cartsManager = Managers.carts
    interactor.myAccountManager = Managers.myAccount
    interactor.userManager = Managers.user
    presenter.viewController = viewController
    router.viewController = viewController
    router.dataStore = interactor
  }

  // MARK: - View's lifecycle

  override func loadView() {
    view = sceneView
  }

  override func viewDidLoad() {
    super.viewDidLoad()
    setupNavigationBar()
    doLoadStaticData()
  }

  // MARK: - Private

  private func setupNavigationBar() {
    let backButton = BackBarButtonItem()
    backButton.delegate = self
    navigationItem.setupLeftBarButtonItems([backButton])

    cartButton.delegate = self
    myAccountButton.delegate = self

    if tabBarController != nil {
      navigationItem.setupRightBarButtonItems([cartButton, myAccountButton])
    } else {
      navigationItem.setupRightBarButtonItems([])
    }
  }
}

// MARK: - Output

extension EpisodeViewController {

  private func doLoadStaticData() {
    let isPresentedInTab = tabBarController != nil
    let request = Episode.StaticData.Request(enableCart: isPresentedInTab, enableMyAccount: isPresentedInTab)
    interactor?.doLoadStaticData(request: request)
  }

  private func doOpenCart() {
    let request = Episode.OpenCart.Request()
    interactor?.doOpenCart(request: request)
  }
}

// MARK: - Input

extension EpisodeViewController: EpisodeDisplayLogic {

  func displayStaticData(viewModel: Episode.StaticData.ViewModel) {
    cartButton.setUnits(viewModel.cartTotalUnits)
    myAccountButton.setBadgeValue(viewModel.myAccountBadgeValue)
  }

  func displayOpenCart(viewModel: Episode.OpenCart.ViewModel) {
    switch viewModel.action {
    case .navigateToCartList:
      router?.routeToCartList()
    case .navigateToLogin:
      router?.routeToLogin()
    }
  }

  func displayUpdateCart(viewModel: Episode.UpdateCart.ViewModel) {
    cartButton.setUnits(viewModel.totalUnits)
  }

  func displayUpdateMyAccount(viewModel: Episode.UpdateMyAccount.ViewModel) {
    myAccountButton.setBadgeValue(viewModel.badgeValue)
  }
}

// MARK: - BackBarButtonItemDelegate

extension EpisodeViewController: BackBarButtonItemDelegate {

  func backBarButtonItemDidPress(_ button: BackBarButtonItem) {
    router?.routeBack()
  }
}

// MARK: - CartBarButtonItemDelegate

extension EpisodeViewController: CartBarButtonItemDelegate {

  func cartBarButtonItemDidPress(_ button: CartBarButtonItem) {
    doOpenCart()
  }
}

// MARK: - MyAccountBarButtonItemDelegate

extension EpisodeViewController: MyAccountBarButtonItemDelegate {

  func myAccountBarButtonItemDidPress(_ button: MyAccountBarButtonItem) {
    router?.routeToMyAccount()
  }
}
