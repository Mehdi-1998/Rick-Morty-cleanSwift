//
//  EpisodePresenter.swift
//  MarvelApp
//
//  Copyright © 2022 ___ORGANIZATIONNAME___. All rights reserved.
//

import Foundation

protocol EpisodePresentationLogic {
  func presentStaticData(response: Episode.StaticData.Response)
  func presentOpenCart(response: Episode.OpenCart.Response)
  func presentUpdateCart(response: Episode.UpdateCart.Response)
  func presentUpdateMyAccount(response: Episode.UpdateMyAccount.Response)
}

class EpisodePresenter: EpisodePresentationLogic {

  // MARK: - Properties

  weak var viewController: EpisodeDisplayLogic?

  // MARK: - Public

  func presentStaticData(response: Episode.StaticData.Response) {
    let badgePresentationHelper = BadgePresentationHelper()
    let myAccountBadge = badgePresentationHelper.getBadgeValue(notificationsCount: response.myAccountNotificationsCount)
    let viewModel = Episode.StaticData.ViewModel(cartTotalUnits: response.cartTotalUnits, myAccountBadgeValue: myAccountBadge)
    viewController?.displayStaticData(viewModel: viewModel)
  }

  func presentOpenCart(response: Episode.OpenCart.Response) {
    let action: OpenCartAction = (response.isUserLoggedIn) ? .navigateToCartList : .navigateToLogin
    let viewModel = Episode.OpenCart.ViewModel(action: action)
    viewController?.displayOpenCart(viewModel: viewModel)
  }

  func presentUpdateCart(response: Episode.UpdateCart.Response) {
    let viewModel = Episode.UpdateCart.ViewModel(totalUnits: response.totalUnits)
    viewController?.displayUpdateCart(viewModel: viewModel)
  }

  func presentUpdateMyAccount(response: Episode.UpdateMyAccount.Response) {
    let badgePresentationHelper = BadgePresentationHelper()
    let badgeValue = badgePresentationHelper.getBadgeValue(notificationsCount: response.notificationsCount)
    let viewModel = Episode.UpdateMyAccount.ViewModel(badgeValue: badgeValue)
    viewController?.displayUpdateMyAccount(viewModel: viewModel)
  }

  // MARK: - Private
}
