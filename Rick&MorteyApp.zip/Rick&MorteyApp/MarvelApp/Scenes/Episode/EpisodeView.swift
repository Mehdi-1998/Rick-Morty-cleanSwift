//
//  EpisodeView.swift
//  MarvelApp
//
//  Copyright © 2022 ___ORGANIZATIONNAME___. All rights reserved.
//

import UIKit

class EpisodeView: UIView {

  // MARK: - Constants

  private struct ViewTraits {
//    // Sizes
//    static let labelWidth: CGFloat = 20
//    static let labelHeight: CGFloat = 20
//
//    // Margins
//    static let labelVMargin: CGFloat = 20
//    static let labelHMargin: CGFloat = 20
  }

  // MARK: - Properties

//  private let label: UILabel = UILabel()

  // MARK: - Lifecycle

  override init(frame: CGRect) {
    super.init(frame: frame)
    setupComponents()
    setupConstraints()
  }

  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }

  // MARK: - Actions

  // MARK: - Public

  func setupUI(data: EpisodeViewData) {
//    label.text = data.text
  }

  // MARK: - Private

  private func setupComponents() {
    backgroundColor = .eciWhite
//
//    addSubviewForAutolayout(label)
  }

  private func setupConstraints() {
//    NSLayoutConstraint.activate([
//      label.centerYAnchor.constraint(equalTo: centerYAnchor),
//      label.leadingAnchor.constraint(equalTo: leadingAnchor, constant: ViewTraits.labelHMargin),
//      label.topAnchor.constraint(greaterThanOrEqualTo: topAnchor, constant: ViewTraits.labelVMargin),
//      trailingAnchor.constraint(equalTo: label.trailingAnchor, constant: ViewTraits.labelHMargin),
//      bottomAnchor.constraint(greaterThanOrEqualTo: label.bottomAnchor, constant: ViewTraits.labelVMargin)
//    ])
  }
}
