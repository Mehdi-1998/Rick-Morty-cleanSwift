//
//  EpisodeInteractor.swift
//  MarvelApp
//
//  Copyright © 2022 ___ORGANIZATIONNAME___. All rights reserved.
//

import Foundation

protocol EpisodeBusinessLogic {
  func doLoadStaticData(request: Episode.StaticData.Request)
  func doOpenCart(request: Episode.OpenCart.Request)
}

protocol EpisodeDataStore {
  var loginReason: LoginReason { get }
}

class EpisodeInteractor: EpisodeBusinessLogic, EpisodeDataStore {

  // MARK: - Properties

  var presenter: EpisodePresentationLogic?
  var cartsManager: CartsManager?
  var myAccountManager: MyAccountManager?
  var userManager: UserManager?

  private(set) var loginReason: LoginReason = .defaultLogin

  // MARK: - Public

  func doLoadStaticData(request: Episode.StaticData.Request) {
    if request.enableCart {
      cartsManager?.register(delegate: self)
    }
    if request.enableMyAccount {
      myAccountManager?.register(delegate: self)
    }
    let cartTotalUnits = cartsManager?.totalUnits ?? 0
    let myAccountNotificationsCount = myAccountManager?.getActiveUnreadNotificationsCount() ?? 0
    let response = Episode.StaticData.Response(cartTotalUnits: cartTotalUnits, myAccountNotificationsCount: myAccountNotificationsCount)
    presenter?.presentStaticData(response: response)
  }

  func doOpenCart(request: Episode.OpenCart.Request) {
    loginReason = .cart
    let isUserLoggedIn = userManager?.isUserLoggedIn() ?? false
    let response = Episode.OpenCart.Response(isUserLoggedIn: isUserLoggedIn)
    presenter?.presentOpenCart(response: response)
  }

  // MARK: - Private
}

// MARK: - CartsManagerDelegate

extension EpisodeInteractor: CartsManagerDelegate {

  func cartsManagerDidUpdate(_ cartsManager: CartsManager, operation: CartOperation) {
    let response = Episode.UpdateCart.Response(totalUnits: cartsManager.totalUnits)
    presenter?.presentUpdateCart(response: response)
  }
}

// MARK: - MyAccountManagerDelegate

extension EpisodeInteractor: MyAccountManagerDelegate {

  func myAccountManager(_ myAccountManager: MyAccountManager, didUpdateActiveNotifications notificationsCount: Int) {
    let response = Episode.UpdateMyAccount.Response(notificationsCount: notificationsCount)
    presenter?.presentUpdateMyAccount(response: response)
  }
}
