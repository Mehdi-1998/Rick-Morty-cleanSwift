//
//  EpisodeModels.swift
//  MarvelApp
//
//  Copyright © 2022 ___ORGANIZATIONNAME___. All rights reserved.
//

import Foundation

// MARK: - Use cases

enum Episode {
  enum StaticData {
    struct Request {
      let enableCart: Bool
      let enableMyAccount: Bool
    }

    struct Response {
      let cartTotalUnits: Int
      let myAccountNotificationsCount: Int
    }

    struct ViewModel {
      let cartTotalUnits: Int
      let myAccountBadgeValue: String?
    }
  }

  enum OpenCart {
    struct Request {
    }

    struct Response {
      let isUserLoggedIn: Bool
    }

    struct ViewModel {
      let action: OpenCartAction
    }
  }

  enum UpdateCart {
    struct Response {
      let totalUnits: Int
    }

    struct ViewModel {
      let totalUnits: Int
    }
  }

  enum UpdateMyAccount {
    struct Response {
      let notificationsCount: Int
    }

    struct ViewModel {
      let badgeValue: String?
    }
  }
}

// MARK: - Business models

// MARK: - View models

struct EpisodeViewData {
//  let text: String
}
