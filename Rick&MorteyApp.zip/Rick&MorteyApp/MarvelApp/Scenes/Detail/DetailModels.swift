//
//  DetailModels.swift
//  MarvelApp
//
//  Copyright © 2022 ___ORGANIZATIONNAME___. All rights reserved.
//

import Foundation

// MARK: - Use cases

enum Detail {
  enum StaticData {
    struct Request {

    }

    struct Response {
      let character: CharacterEntity
    }

    struct ViewModel {
      let viewData: DetailViewData
    }
  }
}

// MARK: - View models

struct DetailViewData {
  let name: String
  let status: String
  let species: String
  let type: String?
  let gender: String
  let origin: OriginViewData
  let location: LocationViewData
  let image: URL?
  let created: String
  let episode: [String]
}

struct OriginViewData: Equatable {
  let name: String
  let url: String
}

struct LocationViewData: Equatable {
  let name: String
  let url: String
}

