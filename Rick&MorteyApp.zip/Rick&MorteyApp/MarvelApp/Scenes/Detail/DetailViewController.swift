//
//  DetailViewController.swift
//  MarvelApp
//
//  Copyright © 2022 ___ORGANIZATIONNAME___. All rights reserved.
//

import UIKit

protocol DetailDisplayLogic: AnyObject {
  func displayStaticData(viewModel: Detail.StaticData.ViewModel)
}

class DetailViewController: UIViewController {

  // MARK: - Properties

  var interactor: DetailBusinessLogic?
  var router: (DetailRoutingLogic & DetailDataPassing)?

  private let sceneView = DetailView()

  // MARK: - Object's lifecycle

  override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
    super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    setup()
  }

  required init?(coder aDecoder: NSCoder) {
    super.init(coder: aDecoder)
    setup()
  }

  // MARK: - Setup

  private func setup() {
    let viewController = self
    let interactor = DetailInteractor()
    let presenter = DetailPresenter()
    let router = DetailRouter()
    viewController.interactor = interactor
    viewController.router = router
    interactor.presenter = presenter
    presenter.viewController = viewController
    router.viewController = viewController
    router.dataStore = interactor
  }

  // MARK: - View's lifecycle

  override func loadView() {
    view = sceneView
  }

  override func viewDidLoad() {
    super.viewDidLoad()
    setupNavigationBar()
    doLoadStaticData()
  }

  // MARK: - Private

  private func setupNavigationBar() {
  }
}

// MARK: - Output

extension DetailViewController {

  private func doLoadStaticData() {
    let request = Detail.StaticData.Request()
    interactor?.doLoadStaticData(request: request)
  }

}

// MARK: - Input

extension DetailViewController: DetailDisplayLogic {

  func displayStaticData(viewModel: Detail.StaticData.ViewModel) {
    sceneView.setupUI(data: viewModel.viewData)
  }
}
