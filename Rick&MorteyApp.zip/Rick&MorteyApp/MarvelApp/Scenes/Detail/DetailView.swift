//
//  DetailView.swift
//  MarvelApp
//
//  Copyright © 2022 ___ORGANIZATIONNAME___. All rights reserved.
//

import UIKit
import Kingfisher

class DetailView: UIView {

  // MARK: - Constants

  private struct ViewTraits {
    // Sizes
    static let labelWidth: CGFloat = 20
    static let labelHeight: CGFloat = 20
    static let imageWidth: CGFloat = UIScreen.main.bounds.width - 40

    // Margins
    static let labelVMargin: CGFloat = 250
    static let labelHMargin: CGFloat = 20
    static let imageTop: CGFloat = 15
    static let imageMargin: CGFloat = 20
    static let titleTop: CGFloat = 25
    static let descriptionTop: CGFloat = 10

    // Fonts
    static let titleFont: CGFloat = 25
    static let descriptionFont: CGFloat = 20
    static let anyTextFont: CGFloat = 15
  }

  // MARK: - Properties

  private let nameLabel: UILabel = UILabel()
  private let descriptionLabel: UILabel = UILabel()
  private let statusLabel: UILabel = UILabel()
  private let statusDataLabel: UILabel = UILabel()
  private let speciesLabel: UILabel = UILabel()
  private let speciesDataLabel: UILabel = UILabel()
  private let originLabel: UILabel = UILabel()
  private let originDataLabel: UILabel = UILabel()
  private let locationLabel: UILabel = UILabel()
  private let locationDataLabel: UILabel = UILabel()
  private let episodeViewButton: UIButton = UIButton()
  private let characterImage: UIImageView = UIImageView()

  private var episodeArray: [EpisodeCellData] = []

  // MARK: - Lifecycle

  override init (frame: CGRect) {
    super.init(frame: frame)
    setupComponents()
    setupConstraints()
  }

  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }

  // MARK: - Actions

  @objc private func didTapEpisodeViewButton (_ sender: Any) {
  }

  // MARK: - Public

  func setupUI(data: DetailViewData) {
    characterImage.kf.setImage(with: data.image)
    nameLabel.text = data.name
    descriptionLabel.text = data.gender
    statusDataLabel.text = data.status
    speciesDataLabel.text = data.species
    originDataLabel.text = data.origin.name
    locationDataLabel.text = data.location.name
  }

  // MARK: - Private

  private func setupComponents() {
    backgroundColor = .white

    nameLabel.textColor = .black
    nameLabel.textAlignment = .center
    nameLabel.numberOfLines = 0
    nameLabel.lineBreakMode = .byWordWrapping
    nameLabel.font = .italicSystemFont(ofSize: ViewTraits.titleFont)

    descriptionLabel.textColor = .brown
    descriptionLabel.textAlignment = .center
    descriptionLabel.numberOfLines = 0
    descriptionLabel.lineBreakMode = .byWordWrapping
    descriptionLabel.font = .systemFont(ofSize: ViewTraits.descriptionFont)

    statusLabel.text = "Status: "
    statusLabel.textColor = .brown
    statusLabel.textAlignment = .left
    statusLabel.numberOfLines = 0
    statusLabel.lineBreakMode = .byWordWrapping
    statusLabel.font = .systemFont(ofSize: ViewTraits.anyTextFont)

    statusDataLabel.textColor = .brown
    statusDataLabel.numberOfLines = 0
    statusDataLabel.lineBreakMode = .byWordWrapping
    statusDataLabel.font = .systemFont(ofSize: ViewTraits.anyTextFont)

    speciesLabel.text = "Specie: "
    speciesLabel.textColor = .brown
    speciesLabel.textAlignment = .left
    speciesLabel.numberOfLines = 0
    speciesLabel.lineBreakMode = .byWordWrapping
    speciesLabel.font = .systemFont(ofSize: ViewTraits.anyTextFont)

    speciesDataLabel.textColor = .brown
    speciesDataLabel.numberOfLines = 0
    speciesDataLabel.lineBreakMode = .byWordWrapping
    speciesDataLabel.font = .systemFont(ofSize: ViewTraits.anyTextFont)

    originLabel.text = "Origin: "
    originLabel.textColor = .brown
    originLabel.textAlignment = .left
    originLabel.numberOfLines = 0
    originLabel.lineBreakMode = .byWordWrapping
    originLabel.font = .systemFont(ofSize: ViewTraits.anyTextFont)

    originDataLabel.textColor = .brown
    originDataLabel.numberOfLines = 0
    originDataLabel.lineBreakMode = .byWordWrapping
    originDataLabel.font = .systemFont(ofSize: ViewTraits.anyTextFont)

    locationLabel.text = "Location: "
    locationLabel.textColor = .brown
    locationLabel.textAlignment = .left
    locationLabel.numberOfLines = 0
    locationLabel.lineBreakMode = .byWordWrapping
    locationLabel.font = .systemFont(ofSize: ViewTraits.anyTextFont)

    locationDataLabel.textColor = .brown
    locationDataLabel.numberOfLines = 0
    locationDataLabel.lineBreakMode = .byWordWrapping
    locationDataLabel.font = .systemFont(ofSize: ViewTraits.anyTextFont)

    episodeViewButton.setTitle("Episodes participated", for: .normal)
    episodeViewButton.setTitleColor(.black, for: .normal)
    episodeViewButton.backgroundColor = .lightGray
    episodeViewButton.addTarget(self, action: #selector(didTapEpisodeViewButton), for: .touchUpInside)

    characterImage.contentMode = .scaleAspectFit

    addSubviewForAutolayout(characterImage)
    addSubviewForAutolayout(nameLabel)
    addSubviewForAutolayout(descriptionLabel)
    addSubviewForAutolayout(statusLabel)
    addSubviewForAutolayout(statusDataLabel)
    addSubviewForAutolayout(speciesLabel)
    addSubviewForAutolayout(speciesDataLabel)
    addSubviewForAutolayout(originLabel)
    addSubviewForAutolayout(originDataLabel)
    addSubviewForAutolayout(locationLabel)
    addSubviewForAutolayout(locationDataLabel)
    addSubviewForAutolayout(episodeViewButton)

  }

  private func setupConstraints() {

    NSLayoutConstraint.activate([
      characterImage.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor, constant: ViewTraits.imageTop),
      characterImage.centerXAnchor.constraint(equalTo: safeAreaLayoutGuide.centerXAnchor),
      characterImage.widthAnchor.constraint(equalToConstant: ViewTraits.imageWidth),
      characterImage.heightAnchor.constraint(equalToConstant: 300),

      nameLabel.topAnchor.constraint(equalTo: characterImage.bottomAnchor, constant: ViewTraits.titleTop),
      nameLabel.leadingAnchor.constraint(equalTo: characterImage.leadingAnchor),
      nameLabel.trailingAnchor.constraint(equalTo: characterImage.trailingAnchor),

      descriptionLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: ViewTraits.titleTop),
      descriptionLabel.leadingAnchor.constraint(equalTo: nameLabel.leadingAnchor),
      descriptionLabel.trailingAnchor.constraint(equalTo: nameLabel.trailingAnchor),

      statusLabel.topAnchor.constraint(equalTo: descriptionLabel.bottomAnchor, constant: ViewTraits.titleTop),
      statusLabel.leadingAnchor.constraint(equalTo: descriptionLabel.leadingAnchor),
      statusLabel.trailingAnchor.constraint(equalTo: descriptionLabel.trailingAnchor),

      statusDataLabel.topAnchor.constraint(equalTo: descriptionLabel.bottomAnchor, constant: ViewTraits.titleTop),
      statusDataLabel.leadingAnchor.constraint(equalTo: statusLabel.leadingAnchor, constant: 75),

      speciesLabel.topAnchor.constraint(equalTo: statusLabel.bottomAnchor, constant: ViewTraits.titleTop),
      speciesLabel.leadingAnchor.constraint(equalTo: statusLabel.leadingAnchor),
      speciesLabel.trailingAnchor.constraint(equalTo: statusLabel.trailingAnchor),

      speciesDataLabel.topAnchor.constraint(equalTo: statusLabel.bottomAnchor, constant: ViewTraits.titleTop),
      speciesDataLabel.leadingAnchor.constraint(equalTo: speciesLabel.leadingAnchor, constant: 75),

      originLabel.topAnchor.constraint(equalTo: speciesLabel.bottomAnchor, constant: ViewTraits.titleTop),
      originLabel.leadingAnchor.constraint(equalTo: speciesLabel.leadingAnchor),
      originLabel.trailingAnchor.constraint(equalTo: speciesLabel.trailingAnchor),

      originDataLabel.topAnchor.constraint(equalTo: speciesLabel.bottomAnchor, constant: ViewTraits.titleTop),
      originDataLabel.leadingAnchor.constraint(equalTo: speciesLabel.leadingAnchor, constant: 75),

      locationLabel.topAnchor.constraint(equalTo: originLabel.bottomAnchor, constant: ViewTraits.titleTop),
      locationLabel.leadingAnchor.constraint(equalTo: originLabel.leadingAnchor),
      locationLabel.trailingAnchor.constraint(equalTo: originLabel.trailingAnchor),

      locationDataLabel.topAnchor.constraint(equalTo: originLabel.bottomAnchor, constant: ViewTraits.titleTop),
      locationDataLabel.leadingAnchor.constraint(equalTo: locationLabel.leadingAnchor, constant: 75),

      episodeViewButton.topAnchor.constraint(equalTo: locationLabel.bottomAnchor, constant: ViewTraits.titleTop),
      episodeViewButton.leadingAnchor.constraint(equalTo: locationLabel.leadingAnchor),
      episodeViewButton.trailingAnchor.constraint(equalTo: locationLabel.trailingAnchor),

    ])
  }
}
// MARK: - UITableViewDataSource

extension DetailView: UITableViewDataSource{

  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    episodeArray.count
  }

  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let item = episodeArray[indexPath.row]
    return createEpisodeCell(tableView: tableView, indexPath: indexPath, data: item)
  }

  private func createEpisodeCell(tableView: UITableView,
                                   indexPath: IndexPath,
                                   data: EpisodeCellData) -> UITableViewCell {

    let reusableCell = tableView.dequeueReusableCell(withIdentifier: EpisodeCell.reuseIdentifier, for: indexPath)
    guard let cell = reusableCell as? EpisodeCell else {
      return reusableCell
    }
    cell.setupUI(data: data)
    return cell
  }
}
