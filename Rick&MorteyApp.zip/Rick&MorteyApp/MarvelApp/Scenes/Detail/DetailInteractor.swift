//
//  DetailInteractor.swift
//  MarvelApp
//
//  Copyright © 2022 ___ORGANIZATIONNAME___. All rights reserved.
//

import Foundation

protocol DetailBusinessLogic {
  func doLoadStaticData(request: Detail.StaticData.Request)
}

protocol DetailDataStore {
  var selectedCharacter: CharacterEntity? { get set }
}

class DetailInteractor: DetailBusinessLogic, DetailDataStore {

  // MARK: - Properties

  var presenter: DetailPresentationLogic?
  var selectedCharacter: CharacterEntity?

  // MARK: - Public
  
  func doLoadStaticData(request: Detail.StaticData.Request) {
    guard let character = selectedCharacter else {
      return
    }
    let response = Detail.StaticData.Response(character: character)
    presenter?.presentStaticData(response: response)
  }
}
