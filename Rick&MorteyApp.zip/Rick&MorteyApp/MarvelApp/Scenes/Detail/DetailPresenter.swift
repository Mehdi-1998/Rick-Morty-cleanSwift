//
//  DetailPresenter.swift
//  MarvelApp
//
//  Copyright © 2022 ___ORGANIZATIONNAME___. All rights reserved.
//

import Foundation

protocol DetailPresentationLogic {
  func presentStaticData(response: Detail.StaticData.Response)
}

class DetailPresenter: DetailPresentationLogic {

  // MARK: - Properties

  weak var viewController: DetailDisplayLogic?

  // MARK: - Public

  func presentStaticData(response: Detail.StaticData.Response) {
    let viewData = getDetailViewData(character: response.character)
    let viewModel = Detail.StaticData.ViewModel(viewData: viewData)
    viewController?.displayStaticData(viewModel: viewModel)
  }

  // MARK: - Private

  private func getDetailViewData(character: CharacterEntity) -> DetailViewData {
    DetailViewData(name: character.name,
                   status: character.status,
                   species: character.species,
                   type: character.type,
                   gender: character.gender,
                   origin: OriginViewData(name: character.origin.name, url: character.origin.url),
                   location: LocationViewData(name: character.location.name, url: character.location.url),
                   image: URL(string: character.image),
                   created: character.created,
                   episode: character.episode)
  }
}
