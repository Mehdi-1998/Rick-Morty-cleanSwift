//
//  DetailRouter.swift
//  MarvelApp
//
//  Copyright © 2022 ___ORGANIZATIONNAME___. All rights reserved.
//

import UIKit

protocol DetailRoutingLogic {
  func routeBack()
}

protocol DetailDataPassing {
  var dataStore: DetailDataStore? { get }
}

class DetailRouter: DetailRoutingLogic, DetailDataPassing {

  // MARK: - Properties

  weak var viewController: DetailViewController?
  var dataStore: DetailDataStore?

  // MARK: - Routing

  func routeBack() {
    viewController?.navigationController?.popViewController(animated: true)
  }

}
