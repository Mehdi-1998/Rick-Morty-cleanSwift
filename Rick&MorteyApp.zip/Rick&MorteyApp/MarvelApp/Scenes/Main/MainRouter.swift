//
//  MainRouter.swift
//  MarvelApp
//
//  Copyright © 2022 ___ORGANIZATIONNAME___. All rights reserved.
//

import UIKit

protocol MainRoutingLogic {
  func routeBack()
  func routeToDetail()
}

protocol MainDataPassing {
  var dataStore: MainDataStore? { get }
}

class MainRouter: MainRoutingLogic, MainDataPassing {
  
  // MARK: - Properties

  weak var viewController: MainViewController?
  var dataStore: MainDataStore?

  // MARK: - Routing

  func routeBack() {
    viewController?.navigationController?.popViewController(animated: true)
  }

  func routeToDetail() {
    let destinationVC = DetailViewController()
    if let sourceDS = dataStore, var destinationDS = destinationVC.router?.dataStore {
      destinationDS.selectedCharacter = sourceDS.selectedCharacter
    }
    viewController?.navigationController?.pushViewController(destinationVC, animated: true)
  }
}
