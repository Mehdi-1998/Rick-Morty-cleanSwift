//
//  MainPresenter.swift
//  MarvelApp
//
//  Copyright © 2022 ___ORGANIZATIONNAME___. All rights reserved.
//

import Foundation

protocol MainPresentationLogic {
  func presentStaticData(response: Main.Data.Response)
  func presentCharacter(response: Main.SelectedCharacter.Response)
}

class MainPresenter: MainPresentationLogic {

  // MARK: - Properties

  weak var viewController: MainDisplayLogic?

  // MARK: - Public

  func presentStaticData(response: Main.Data.Response) {
    var action: MainAction
    var charactersCellData: [CharacterCellData] = []
    switch response.result {
    case .success(let characters):
      charactersCellData = characters.map({ character in
        CharacterCellData(image: URL(string: character.image), title: character.name)
      })
      action = .showData(data: MainViewData(characters: charactersCellData))
    case .failure:
      action = .showError(error: "Impossible to show character.")
    }
    let viewModel = Main.Data.ViewModel(action: action)
    viewController?.displayStaticData(viewModel: viewModel)
  }

  func presentCharacter(response: Main.SelectedCharacter.Response) {
    viewController?.displayCharacter(viewModel: Main.SelectedCharacter.ViewModel())
  }
}
