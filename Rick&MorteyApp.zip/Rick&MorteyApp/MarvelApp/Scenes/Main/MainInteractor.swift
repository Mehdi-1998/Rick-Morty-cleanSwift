//
//  MainInteractor.swift
//  MarvelApp
//
//  Copyright © 2022 ___ORGANIZATIONNAME___. All rights reserved.
//

import Foundation

protocol MainBusinessLogic {
  func doLoadStaticData(request: Main.Data.Request)
  func doSelectedCharacter(request: Main.SelectedCharacter.Request)
}

protocol MainDataStore {
  var selectedCharacter: CharacterEntity? { get set }
}

class MainInteractor: MainBusinessLogic, MainDataStore {

  // MARK: - Properties

  var presenter: MainPresentationLogic?
  var rickAndMortyApi: RickAndMortyApi?

  var selectedCharacter: CharacterEntity?

  var characters: [CharacterEntity] = []

  // MARK: - Public

  func doLoadStaticData(request: Main.Data.Request) {
    rickAndMortyApi?.getCharacters { [weak self] result in
      if case let .success(characters) = result {
        self?.characters = characters
      }
      let response = Main.Data.Response(result: result)
      self?.presenter?.presentStaticData(response: response)
    }
  }

  func doSelectedCharacter(request: Main.SelectedCharacter.Request) {
    selectedCharacter = characters[request.index]
    presenter?.presentCharacter(response: Main.SelectedCharacter.Response())
  }
}
