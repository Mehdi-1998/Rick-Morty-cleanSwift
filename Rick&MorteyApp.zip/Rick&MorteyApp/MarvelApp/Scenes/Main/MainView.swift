//
//  MainView.swift
//  MarvelApp
//
//  Copyright © 2022 ___ORGANIZATIONNAME___. All rights reserved.
//

import UIKit

protocol MainViewDelegate: AnyObject {
  func mainViewSearchCharacter(_ view: MainView, searchTerm: String)
  func mainViewRowDidTap(_ view: MainView, index: Int)
}

class MainView: UIView {

  // MARK: - Constants

  private struct ViewTraits {
    // Margins
    static let buttonMarginTop: CGFloat = 24
    static let headerMargin: CGFloat = 24
    static let imageTextFliedMargin: CGFloat = 10

    // Sizes
    static let estimatedSectionHeaderHeight: CGFloat = 100
    static let estimatedRowHeight: CGFloat = 100
    static let iconSize: CGFloat = 20
  }

  // MARK: - Properties

  weak var delegate: MainViewDelegate?

  private let headerView = UIView()
  private let imageTextField = UIImageView(image: UIImage(systemName: "magnifyingglass"))
  private let deleteSearchButton = UIButton()
  private let textField = UITextField()
  private let tableView = UITableView(frame: .zero, style: .grouped)
  private let spinning = UIActivityIndicatorView(style: .large)

  private var characterArray: [CharacterCellData] = []

  // MARK: - Lifecycle

  override init(frame: CGRect) {
    super.init(frame: frame)
    setupComponents()
    setupConstraints()
  }

  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }

  // MARK: - Actions

  @objc private func didTapDeleteButton(_ sender: Any) {
    textField.text = ""
  }

  // MARK: - Public

  func setupUI(data: MainViewData) {
    characterArray = data.characters
    tableView.reloadData()
  }

  func showSpinning() {
    spinning.startAnimating()
  }

  func hideSpinning() {
    spinning.stopAnimating()
  }

  // MARK: - Private

  private func setupComponents() {
    headerView.backgroundColor = .yellow
    headerView.layer.cornerRadius = 5

    imageTextField.tintColor = .black

    deleteSearchButton.setImage(UIImage(systemName: "xmark.circle"), for: .normal)
    deleteSearchButton.setImage(UIImage(systemName: "xmark.circle.fill"), for: .highlighted)
    deleteSearchButton.addTarget(self, action: #selector(didTapDeleteButton), for: .touchUpInside)

    textField.placeholder = "Search you character here.."
    textField.delegate = self

    tableView.dataSource = self
    tableView.delegate = self
    tableView.backgroundColor = .black
    tableView.sectionHeaderHeight = UITableView.automaticDimension
    tableView.estimatedSectionHeaderHeight = ViewTraits.estimatedSectionHeaderHeight
    tableView.rowHeight = UITableView.automaticDimension
    tableView.estimatedRowHeight = ViewTraits.estimatedRowHeight
    tableView.separatorStyle = .none
    tableView.sectionFooterHeight = CGFloat.leastNormalMagnitude
    tableView.tableFooterView = UIView(frame: .zero)
    tableView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: ViewTraits.buttonMarginTop, right: 0)
    tableView.register(CharacterCell.self, forCellReuseIdentifier: CharacterCell.reuseIdentifier)

    spinning.color = .yellow

    headerView.addSubviewForAutolayout(textField)
    headerView.addSubviewForAutolayout(imageTextField)
    headerView.addSubviewForAutolayout(deleteSearchButton)

    addSubviewForAutolayout(headerView)
    addSubviewForAutolayout(tableView)
    addSubviewForAutolayout(spinning)

  }
  private func setupConstraints() {
    NSLayoutConstraint.activate([
      headerView.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor),
      headerView.leadingAnchor.constraint(equalTo: safeAreaLayoutGuide.leadingAnchor),
      headerView.trailingAnchor.constraint(equalTo: safeAreaLayoutGuide.trailingAnchor),

      tableView.topAnchor.constraint(equalTo: headerView.bottomAnchor),
      tableView.bottomAnchor.constraint(equalTo: safeAreaLayoutGuide.bottomAnchor),
      tableView.leadingAnchor.constraint(equalTo: safeAreaLayoutGuide.leadingAnchor),
      tableView.trailingAnchor.constraint(equalTo: safeAreaLayoutGuide.trailingAnchor),

      imageTextField.centerYAnchor.constraint(equalTo: textField.centerYAnchor),
      imageTextField.trailingAnchor.constraint(equalTo: textField.leadingAnchor,
                                               constant: -ViewTraits.imageTextFliedMargin),
      imageTextField.leadingAnchor.constraint(equalTo: headerView.leadingAnchor, constant: ViewTraits.headerMargin),
      imageTextField.widthAnchor.constraint(equalToConstant: 20),
      imageTextField.heightAnchor.constraint(equalToConstant: 20),

      textField.topAnchor.constraint(equalTo: headerView.topAnchor, constant: ViewTraits.headerMargin),
      textField.bottomAnchor.constraint(equalTo: headerView.bottomAnchor, constant: -ViewTraits.headerMargin),

      deleteSearchButton.centerYAnchor.constraint(equalTo: textField.centerYAnchor),
      deleteSearchButton.leadingAnchor.constraint(equalTo: textField.trailingAnchor, constant: 5),
      deleteSearchButton.trailingAnchor.constraint(equalTo: headerView.trailingAnchor,
                                                   constant: -ViewTraits.headerMargin),
      deleteSearchButton.widthAnchor.constraint(equalToConstant: 20),
      deleteSearchButton.heightAnchor.constraint(equalToConstant: 20),

      spinning.centerXAnchor.constraint(equalTo: centerXAnchor),
      spinning.centerYAnchor.constraint(equalTo: centerYAnchor)
    ])
  }
}

// MARK: - UITableViewDataSource

extension MainView: UITableViewDataSource{

  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    characterArray.count
  }

  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let item = characterArray[indexPath.row]
    return createCharacterCell(tableView: tableView, indexPath: indexPath, data: item)
  }

  private func createCharacterCell(tableView: UITableView,
                                   indexPath: IndexPath,
                                   data: CharacterCellData) -> UITableViewCell {

    let reusableCell = tableView.dequeueReusableCell(withIdentifier: CharacterCell.reuseIdentifier, for: indexPath)
    guard let cell = reusableCell as? CharacterCell else {
      return reusableCell
    }
    cell.setupUI(data: data)
    return cell
  }

}

// MARK: - UITableViewDelegate

extension MainView: UITableViewDelegate {

  func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    delegate?.mainViewRowDidTap(self, index: indexPath.row)
  }
}

// MARK: - UITextFieldDelegate

extension MainView: UITextFieldDelegate {

  func textFieldShouldReturn(_ textField: UITextField) -> Bool {
    delegate?.mainViewSearchCharacter(self, searchTerm: textField.text ?? "")
    return false
  }
}
