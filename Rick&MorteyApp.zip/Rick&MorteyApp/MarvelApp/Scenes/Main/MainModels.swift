//
//  MainModels.swift
//  MarvelApp
//
//  Copyright © 2022 ___ORGANIZATIONNAME___. All rights reserved.
//

import Foundation

// MARK: - Use cases

enum Main {

  enum Data {
    struct Request {
    }

    struct Response {
      let result: Result<[CharacterEntity], GetCharactersError>
    }

    struct ViewModel {
      let action: MainAction
    }
  }

  enum SelectedCharacter {
    struct Request {
      let index: Int
    }

    struct Response {

    }

    struct ViewModel {

    }
  }
}

// MARK: - View models

struct MainViewData: Equatable {
  let characters: [CharacterCellData]
}

enum MainAction: Equatable {
  case showData(data: MainViewData)
  case showError(error: String)
}
