//
//  MainViewController.swift
//  MarvelApp
//
//  Copyright © 2022 ___ORGANIZATIONNAME___. All rights reserved.
//

import UIKit
import Foundation
import Alamofire


protocol MainDisplayLogic: AnyObject {
  func displayStaticData(viewModel: Main.Data.ViewModel)
  func displayCharacter(viewModel: Main.SelectedCharacter.ViewModel)
}

class MainViewController: UIViewController, UITableViewDelegate {


  // MARK: - Properties

  var interactor: MainBusinessLogic?
  var router: (MainRoutingLogic & MainDataPassing)?

  private let sceneView = MainView()

  // MARK: - Object's lifecycle

  override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
    super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    setup()
  }

  required init?(coder aDecoder: NSCoder) {
    super.init(coder: aDecoder)
    setup()
  }

  // MARK: - Setup

  private func setup() {
    let viewController = self
    let interactor = MainInteractor()
    let presenter = MainPresenter()
    let router = MainRouter()
    viewController.interactor = interactor
    viewController.router = router
    interactor.presenter = presenter
    interactor.rickAndMortyApi = Managers.network
    presenter.viewController = viewController
    router.viewController = viewController
    router.dataStore = interactor
  }

  // MARK: - View's lifecycle

  override func loadView() {
    view = sceneView
  }

  override func viewDidLoad() {
    super.viewDidLoad()
    setupComponents()
    doLoadStaticData()
  }

  // MARK: - Actions

  @objc private func didTapBackButton(_ sender: Any) {
    router?.routeBack()
  }

  // MARK: - Private

  private func setupComponents() {
    sceneView.delegate = self
  }

  private func showError(_ error: String) {
    let alert = UIAlertController(title: "ERROR",
                                  message: error,
                                  preferredStyle: UIAlertController.Style.alert)

    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))

    self.present(alert, animated: true, completion: nil)
  }
}

// MARK: - Output

extension MainViewController {
// quitar static
  private func doLoadStaticData() {
    sceneView.showSpinning()
    let request = Main.Data.Request()
    interactor?.doLoadStaticData(request: request)
  }

  private func doSelectCharacter(index: Int) {
    let request = Main.SelectedCharacter.Request(index: index)
    interactor?.doSelectedCharacter(request: request)
  }
}

// MARK: - Input

extension MainViewController: MainDisplayLogic {
  
  func displayStaticData(viewModel: Main.Data.ViewModel) {
    sceneView.hideSpinning()
    switch viewModel.action {
    case.showData(let data):
      sceneView.setupUI(data: data)
    case .showError(let error):
      showError(error)
    }
  }
// displaySelectedCharacter
  func displayCharacter(viewModel: Main.SelectedCharacter.ViewModel) {
    router?.routeToDetail()
  }
}

// MARK: - CodeViewDelegate

extension MainViewController: MainViewDelegate {

  func mainViewSearchCharacter(_ view: MainView, searchTerm: String) {
  }

  func mainViewRowDidTap(_ view: MainView, index: Int) {
    doSelectCharacter(index: index)
  }
}
