//
//  RickAndMortyEntities.swift
//  MarvelApp
//
//  Created by Vicente Linares, Miguel on 10/10/22.
//

import Foundation

// MARK: - Entities

struct CharacterEntity: Equatable {
  let id: Int
  let name: String
  let status: String
  let species: String
  let type: String?
  let gender: String
  let origin: OriginEntity
  let location: LocationEntity
  let image: String
  let url: String
  let created: String
  let episode: [String]
}

struct OriginEntity: Equatable {
  let name: String
  let url: String
}

struct LocationEntity: Equatable {
  let name: String
  let url: String
}

// MARK: - Errors

enum GetCharactersError: Error {
  case responeProblems
}
