//
//  UITableView.swift
//  MarvelApp
//
//  Created by mehdi.jahanmard on 15/12/22.
//

import UIKit

extension UITableViewCell {

  static var reuseIdentifier: String {
    String(describing: Self.self)
  }
}
