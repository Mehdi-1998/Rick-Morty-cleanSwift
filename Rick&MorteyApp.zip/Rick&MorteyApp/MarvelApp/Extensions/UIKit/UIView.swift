//
//  UIView.swift
//  MarvelApp
//
//  Created by Vicente Linares, Miguel on 10/10/22.
//

import UIKit

extension UIView {

  func addSubviewForAutolayout(_ subview: UIView) {
    subview.translatesAutoresizingMaskIntoConstraints = false
    addSubview(subview)
  }
}
