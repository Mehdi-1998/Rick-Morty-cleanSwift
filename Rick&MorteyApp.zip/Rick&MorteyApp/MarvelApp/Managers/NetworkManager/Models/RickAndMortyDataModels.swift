//
//  RickAndMortyDataModels.swift
//  MarvelApp
//
//  Created by mehdi.jahanmard on 14/11/22.
//

import Foundation

// MARK: - Response

struct CharacterAPIResult: Decodable {
  let info: InfoData
  let results: [CharacterData]

  func domainEntity() -> [CharacterEntity] {
    results.map { character in
      let origin = OriginEntity(name: character.origin.name, url: character.origin.url)
      let location = LocationEntity(name: character.location.name, url: character.location.url)
      return CharacterEntity(id: character.id,
                      name: character.name,
                      status: character.status,
                      species: character.species,
                      type: character.type,
                      gender: character.gender,
                      origin: origin,
                      location: location,
                      image: character.image,
                      url: character.url,
                      created: character.created,
                      episode: character.episode)
    }
  }
}

struct APICharacterData: Decodable {
  let info: InfoData
  let results: [CharacterData]
}

struct InfoData: Decodable {
  let count: Int
  let pages: Int
  let next: String?
  let prev: String?
}

struct CharacterData: Decodable {
  let id: Int
  let name: String
  let status: String
  let species: String
  let type: String?
  let gender: String
  let origin: OriginData
  let location: LocationData
  let image: String
  let url: String
  let created: String
  let episode: [String]
}

struct OriginData: Decodable {
  let name: String
  let url: String
}

struct LocationData: Decodable {
  let name: String
  let url: String
}

struct Thumbnail: Decodable {

  enum CodingKeys: String, CodingKey {
    case path
    case imageExtension = "extension"
  }

  let path: String
  let imageExtension: String

  func getUrl() -> URL? {
    URL(string: "\(path).\(imageExtension)")
  }

}

