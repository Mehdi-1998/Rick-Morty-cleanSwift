//
//  NetworkManager.swift
//  MarvelApp
//
//  Created by mehdi.jahanmard on 11/11/22.
//

import Foundation

class DefaultNetworkManager {

  // MARK: - Properties

  let networkConfigManager: NetworkConfigManager

  // MARK: - Lifecycle

  init(networkConfigManager: NetworkConfigManager) {
    self.networkConfigManager = networkConfigManager
  }
}
