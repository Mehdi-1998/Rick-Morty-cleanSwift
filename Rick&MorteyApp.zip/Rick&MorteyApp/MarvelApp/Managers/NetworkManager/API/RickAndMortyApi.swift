//
//  RickAndMortyApi.swift
//  MarvelApp
//
//  Created by mehdi.jahanmard on 11/11/22.
//

import Foundation

private enum RickAndMortyApiEndpoint {
  static let characters = "/api/character"
}

protocol RickAndMortyApi {
  func getCharacters(completion: @escaping (Result<[CharacterEntity], GetCharactersError>) -> Void)
}

extension DefaultNetworkManager: RickAndMortyApi {

  func getCharacters(completion: @escaping (Result<[CharacterEntity], GetCharactersError>) -> Void) {
    var urlComponents = URLComponents(string: "https://rickandmortyapi.com")
    urlComponents?.path = RickAndMortyApiEndpoint.characters
    guard let url = urlComponents?.url else {
      DispatchQueue.main.async {
        completion(.failure(.responeProblems))
      }
      return
    }

    let session = URLSession(configuration: .default)
    session.dataTask(with: url) { (data, _, error) in
      guard let data = data, error == nil else {
        DispatchQueue.main.async {
          completion(.failure(.responeProblems))
        }
        return
      }

      do {
        let apiResults = try JSONDecoder().decode(CharacterAPIResult.self, from: data)
        let characters = apiResults.domainEntity()
        DispatchQueue.main.async {
          completion(.success(characters))
        }
      } catch {
        print(error)
        DispatchQueue.main.async {
          completion(.failure(.responeProblems))
        }
      }
    }
    .resume()
  }
}
