//
//  Managers.swift
//  MarvelApp
//
//  Created by mehdi.jahanmard on 11/11/22.
//

import Foundation

struct Managers {
  static let network = DefaultNetworkManager(networkConfigManager: networkConfig)
  static let networkConfig = DefaultNetworkConfigManager()
}
