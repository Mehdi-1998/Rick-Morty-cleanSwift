//
//  File.swift
//  MarvelApp
//
//  Created by mehdi.jahanmard on 11/11/22.
//

import Foundation

protocol NetworkConfigManager {
  var marvelPublicKey: String { get }
  func getMarvelHash(timestamp: String) -> String
}

class DefaultNetworkConfigManager: NetworkConfigManager {

  // MARK: - Properties

  let marvelPublicKey = "b70d27f423351df4a91de11fcc978031"

  private let marvelPrivateKey = "5ef4c040542ae259574b7d3873da108a42148ef3"

  // MARK: - Public

  func getMarvelHash(timestamp: String) -> String {
    "\(timestamp)\(marvelPrivateKey)\(marvelPublicKey)".md5()
  }

}
